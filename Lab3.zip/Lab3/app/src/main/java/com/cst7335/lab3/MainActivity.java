package com.cst7335.lab3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText emailEditText; // EditText for email input
    private EditText passwordEditText; // EditText for password input
    private Button loginButton; // Button to trigger login
    private SharedPreferences sharedPreferences; // SharedPreferences to save user data

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set the layout for this activity

        // Initialize views
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        // Load saved email from SharedPreferences
        sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedEmail = sharedPreferences.getString("email", "");
        emailEditText.setText(savedEmail); // Set the saved email to the EditText

        // Set click listener for the login button
        loginButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString(); // Get email input
            Intent goToProfile = new Intent(MainActivity.this, ProfileActivity.class); // Create intent to go to ProfileActivity
            goToProfile.putExtra("EMAIL", email); // Pass the email to the ProfileActivity
            startActivity(goToProfile); // Start the ProfileActivity
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Save email in SharedPreferences when the activity is paused
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", emailEditText.getText().toString()); // Save the email input
        editor.apply(); // Apply changes
    }
}
